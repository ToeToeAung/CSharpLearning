using Microsoft.Extensions.Hosting;

namespace OrderprocessingWorker;
public class Worker : BackgroundService
{
    private readonly ILogger<Worker> _logger;
    private int count=0;
    public Worker(ILogger<Worker> logger)
    {
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            if (_logger.IsEnabled(LogLevel.Information))
            {
                _logger.LogInformation($"Worker has run {count} times.");
                count++;
            }
            await Task.Delay(1000, stoppingToken);
        }
    }

    public override Task StartAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Worker is starting ..");
        return base.StartAsync(cancellationToken);
    }

    public override Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Worker is stopping..");
        return base.StopAsync(cancellationToken);
    }
}

